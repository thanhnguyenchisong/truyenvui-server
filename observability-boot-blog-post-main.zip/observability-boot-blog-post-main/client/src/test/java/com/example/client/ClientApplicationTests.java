package com.example.client;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("we don't want to send a request")
class ClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
