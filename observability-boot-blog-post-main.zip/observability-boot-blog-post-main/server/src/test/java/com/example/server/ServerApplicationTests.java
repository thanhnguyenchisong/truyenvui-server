package com.example.server;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureObservability
class ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
